<?php
/*
Plugin Name: Logixsaas
Plugin URI: https://logixsaas.com
Description: Logixsaas order fulfillment plugin.
Version: 1.0
Author: Logixsaas
Author URI: https://logixsaas.com
*/


// Exit if accessed directly
if (!defined('ABSPATH')) {
  exit;
}

class Logixsaas_Plugin
{
  private $order_prefix;
  private $domain;
  private $client_code;
  // class constructor
  public function __construct()
  {
    // register actions
    add_action('admin_init', array($this, 'init_settings'));
    add_action('woocommerce_checkout_order_processed', array($this, 'logixsaas_send_webhook'));
    add_action('admin_menu', array($this, 'custom_settings_page'));

    add_action('admin_enqueue_scripts', array($this, 'my_plugin_enqueue_scripts'));
  }
  public function my_plugin_enqueue_scripts()
  {
    wp_enqueue_style('style', plugin_dir_url(__FILE__) . 'style.css');
  }

  public function init_settings()
  {
    register_setting('logixsaas_settings', 'api_order_prefix');
    register_setting('logixsaas_settings', 'api_domain');
    register_setting('logixsaas_settings', 'api_client_code');
  }

  // https://e3d9-197-254-17-154.eu.ngrok.io
  // send the webhook
  public function logixsaas_send_webhook($order_id)
  {

    $order_prefix = get_option('api_order_prefix');
    $domain = get_option('api_domain');
    $client_code = get_option('api_client_code');
    // code to send the webhook
    // Set the URL to post data to

    if ($domain && $client_code) {
      $url = 'https://' . $domain .  '.logixsaas.com/api/plugin_orders';
      $order = new WC_Order($order_id);
      $order_data = $order->get_data();
      $line_items = array();
      foreach ($order->get_items() as $item_id => $item) {
        $product = $item->get_product();
        $line_item = array(
          'name' => $product->get_name(),
          'quantity' => $item->get_quantity(),
          'price' => $item->get_total(),
        );
        $line_items[] = $line_item;
      }
      $data = array_merge($order_data, array('line_items' => $line_items));
      $data['prefix'] = $order_prefix;
      $data['client_code'] = $client_code;

      // Use the wp_remote_post() function to post the data
      $response = wp_remote_post($url, array(
        'method' => 'POST',
        'timeout' => 45,
        'redirection' => 5,
        'httpversion' => '1.0',
        'blocking' => true,
        'headers' => array(),
        'body' => $data,
        'cookies' => array()
      ));
    }

    // Check for any errors
    if (is_wp_error($response)) {
      // Handle error
    } else {
      // Handle success
    }
  }



  public function custom_settings_page()
  {
    add_menu_page('Logixsaas', 'Logixsaas', 'manage_options', 'big-daddy-media', array($this, 'settings_page'));
  }


  public function settings_page()
  {
    if (!current_user_can('manage_options')) {
      wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    $this->order_prefix = get_option('api_order_prefix');
    $this->domain = get_option('api_domain');
    $this->client_code = get_option('api_client_code');

?>
    <div class="wrap">
      <h1>Logixsaas Settings</h1>
      <form method="post" action="options.php">
        <?php settings_fields('logixsaas_settings'); ?>
        <?php do_settings_sections('logixsaas_settings'); ?>
        <table class="form-table">
          <tr>
            <th scope="row"> <b title="Your order prefered prefix">Order Prefix</b> </th>
            <td><input type="text" name="api_order_prefix" value="<?php echo esc_attr($this->order_prefix); ?>"></td>
          </tr>
          <tr>
            <th scope="row"> <b title="Get from the admin">Domain</b> </th>
            <td><input type="text" name="api_domain" value="<?php echo esc_attr($this->domain); ?>"></td>
          </tr>
          <tr>
            <th scope="row"> <b title="Get from the admin">Client code</b>
            </th>
            <td><input type="text" name="api_client_code" value="<?php echo esc_attr($this->client_code); ?>"></td>
          </tr>
        </table>
        <?php submit_button(); ?>
      </form>
    </div>
<?php
  }
}
// wp_enqueue_script( 'my-vue-plugin', plugin_dir_url( __FILE__ ) . 'my-vue-plugin.js', array( 'vue' ), '1.0', true );
// instantiate the plugin class
$logixsaas_plugin = new Logixsaas_Plugin();
